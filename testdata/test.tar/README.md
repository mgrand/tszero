# tszero
Filter for tar and zip archives that sets all timestamps to zero. This allows archives with content that is the same except for timestamps to compare as equal.
